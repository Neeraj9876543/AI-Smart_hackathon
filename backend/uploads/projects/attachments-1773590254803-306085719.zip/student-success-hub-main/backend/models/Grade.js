const mongoose = require('mongoose');

const gradeSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  assignment: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Assignment',
    required: true
  },
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course',
    required: true
  },
  score: {
    type: Number,
    required: true,
    min: 0
  },
  maxPoints: {
    type: Number,
    required: true,
    min: 1
  },
  percentage: {
    type: Number,
    min: 0,
    max: 100
  },
  feedback: {
    type: String,
    default: ''
  },
  gradedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  gradedAt: {
    type: Date,
    default: Date.now
  },
  isLate: {
    type: Boolean,
    default: false
  },
  submissionDate: {
    type: Date
  }
});

gradeSchema.pre('save', function(next) {
  if (this.score !== undefined && this.maxPoints) {
    this.percentage = (this.score / this.maxPoints) * 100;
  }
  next();
});

gradeSchema.index({ student: 1, course: 1 });
gradeSchema.index({ assignment: 1, student: 1 }, { unique: true });

module.exports = mongoose.model('Grade', gradeSchema);

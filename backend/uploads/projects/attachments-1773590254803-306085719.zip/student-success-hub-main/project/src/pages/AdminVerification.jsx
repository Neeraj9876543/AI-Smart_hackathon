import React from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, Eye } from 'lucide-react';

export default function AdminVerification() {
  const { students, documents, achievements, verifyDocument, verifyAchievement } = useAuth();
  const pendingDocs = documents.filter(d => d.status === 'Pending');
  const pendingAchs = achievements.filter(a => a.status === 'Pending');

  return (
    <div className="space-y-8">
      <h2 className="text-xl font-display font-bold text-foreground">Verification Panel</h2>

      {/* Pending Documents */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-2xl border border-border shadow-soft overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="font-bold text-foreground">Pending Documents ({pendingDocs.length})</h3>
        </div>
        {pendingDocs.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">All documents are verified ✅</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-secondary/50">
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Student</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Document</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Uploaded</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {pendingDocs.map(doc => {
                  const student = students.find(s => s.id === doc.studentId);
                  return (
                    <tr key={doc.id} className="hover:bg-secondary/30 transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-sm font-medium text-foreground">{student?.name}</p>
                        <p className="text-xs text-muted-foreground">{student?.regNo}</p>
                      </td>
                      <td className="px-6 py-4 text-sm text-foreground">{doc.type}</td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">{doc.uploadedDate}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button onClick={() => verifyDocument(doc.id, 'Verified')}
                            className="flex items-center gap-1 px-3 py-1.5 bg-success/10 text-success rounded-lg text-xs font-semibold hover:bg-success/20 transition-colors">
                            <CheckCircle size={14} /> Approve
                          </button>
                          <button onClick={() => verifyDocument(doc.id, 'Rejected')}
                            className="flex items-center gap-1 px-3 py-1.5 bg-destructive/10 text-destructive rounded-lg text-xs font-semibold hover:bg-destructive/20 transition-colors">
                            <XCircle size={14} /> Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Pending Achievements */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
        className="bg-card rounded-2xl border border-border shadow-soft overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="font-bold text-foreground">Pending Achievements ({pendingAchs.length})</h3>
        </div>
        {pendingAchs.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">All achievements are verified ✅</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-secondary/50">
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Student</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Achievement</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Type</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {pendingAchs.map(ach => {
                  const student = students.find(s => s.id === ach.studentId);
                  return (
                    <tr key={ach.id} className="hover:bg-secondary/30 transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-sm font-medium text-foreground">{student?.name}</p>
                        <p className="text-xs text-muted-foreground">{student?.regNo}</p>
                      </td>
                      <td className="px-6 py-4 text-sm text-foreground">{ach.title}</td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">{ach.type}</td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">{ach.date}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button onClick={() => verifyAchievement(ach.id, 'Verified')}
                            className="flex items-center gap-1 px-3 py-1.5 bg-success/10 text-success rounded-lg text-xs font-semibold hover:bg-success/20 transition-colors">
                            <CheckCircle size={14} /> Approve
                          </button>
                          <button onClick={() => verifyAchievement(ach.id, 'Rejected')}
                            className="flex items-center gap-1 px-3 py-1.5 bg-destructive/10 text-destructive rounded-lg text-xs font-semibold hover:bg-destructive/20 transition-colors">
                            <XCircle size={14} /> Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>
    </div>
  );
}

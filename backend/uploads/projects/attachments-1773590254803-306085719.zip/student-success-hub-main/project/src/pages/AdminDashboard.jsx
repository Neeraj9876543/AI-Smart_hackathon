import React from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Users, Trophy, FileCheck, Clock, TrendingUp } from 'lucide-react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

export default function AdminDashboard() {
  const { students, achievements, documents } = useAuth();
  const verified = documents.filter(d => d.status === 'Verified').length;
  const pending = documents.filter(d => d.status === 'Pending').length;

  const stats = [
    { icon: Users, label: 'Total Students', value: students.length, color: 'bg-primary/10 text-primary' },
    { icon: Trophy, label: 'Total Achievements', value: achievements.length, color: 'bg-warning/10 text-warning' },
    { icon: FileCheck, label: 'Verified Documents', value: verified, color: 'bg-success/10 text-success' },
    { icon: Clock, label: 'Pending Documents', value: pending, color: 'bg-destructive/10 text-destructive' },
  ];

  const typeCount = achievements.reduce((acc, a) => {
    acc[a.type] = (acc[a.type] || 0) + 1;
    return acc;
  }, {});

  const branchCount = students.reduce((acc, s) => {
    const count = achievements.filter(a => a.studentId === s.id).length;
    acc[s.branch] = (acc[s.branch] || 0) + count;
    return acc;
  }, {});

  const doughnutData = {
    labels: Object.keys(typeCount),
    datasets: [{ data: Object.values(typeCount), backgroundColor: ['#2563EB', '#06B6D4', '#F59E0B', '#10B981', '#8B5CF6', '#EF4444', '#EC4899'], borderWidth: 0 }]
  };

  const barData = {
    labels: Object.keys(branchCount),
    datasets: [{ label: 'Achievements', data: Object.values(branchCount), backgroundColor: '#2563EB', borderRadius: 8, barThickness: 40 }]
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card p-6 rounded-2xl border border-border shadow-soft"
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${stat.color}`}>
              <stat.icon size={20} />
            </div>
            <p className="text-muted-foreground text-sm font-medium">{stat.label}</p>
            <h3 className="text-2xl font-bold text-foreground mt-1">{stat.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="bg-card p-6 rounded-2xl border border-border shadow-soft">
          <h3 className="font-bold text-foreground mb-6">Achievements by Category</h3>
          <div className="max-w-[280px] mx-auto">
            <Doughnut data={doughnutData} options={{ plugins: { legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true } } }, cutout: '65%' }} />
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          className="bg-card p-6 rounded-2xl border border-border shadow-soft">
          <h3 className="font-bold text-foreground mb-6">Achievements by Department</h3>
          <Bar data={barData} options={{ plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } }, x: { grid: { display: false } } } }} />
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}
        className="bg-card rounded-2xl border border-border shadow-soft overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="font-bold text-foreground">Recent Student Activity</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-secondary/50">
                <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Student</th>
                <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Achievement</th>
                <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Type</th>
                <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {achievements.slice(0, 6).map((ach, i) => {
                const student = students.find(s => s.id === ach.studentId);
                return (
                  <tr key={i} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-foreground">{student?.name}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{ach.title}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{ach.type}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        ach.status === 'Verified' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                      }`}>{ach.status}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}

import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { FileText, Upload, CheckCircle, Clock, Eye } from 'lucide-react';

const docTypes = ['Aadhaar', 'PAN Card', 'Mark Memo (Sem 1-4)', 'APAAR / ABC ID', 'Transfer Certificate', 'Income Certificate', 'Caste Certificate', 'Study Certificate', '10th Memo', 'Inter Memo'];

export default function DocumentRepository() {
  const { user, getStudentDocs } = useAuth();
  const documents = getStudentDocs(user?.id);
  const [showUpload, setShowUpload] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-display font-bold text-foreground">Document Repository</h2>
        <button
          onClick={() => setShowUpload(!showUpload)}
          className="flex items-center gap-2 gradient-brand text-primary-foreground px-4 py-2.5 rounded-lg text-sm font-semibold"
        >
          <Upload size={16} /> Upload Document
        </button>
      </div>

      {showUpload && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-2xl border border-border shadow-soft p-6"
        >
          <h3 className="font-bold text-foreground mb-4">Upload New Document</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Document Type</label>
              <select className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30">
                {docTypes.map(type => <option key={type}>{type}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Upload File (PDF/Image)</label>
              <div className="border-2 border-dashed border-border rounded-lg px-4 py-3 text-center hover:border-primary/50 transition-colors cursor-pointer">
                <p className="text-sm text-muted-foreground">Click to browse or drag & drop</p>
              </div>
            </div>
          </div>
          <button className="mt-4 gradient-brand text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-semibold">
            Submit Document
          </button>
        </motion.div>
      )}

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {docTypes.map((type, i) => {
          const doc = documents.find(d => d.type === type);
          return (
            <motion.div
              key={type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-2xl border border-border shadow-card p-5 hover:shadow-soft transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <FileText className="text-muted-foreground" size={18} />
                </div>
                {doc && (
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    doc.status === 'Verified' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                  }`}>
                    {doc.status}
                  </span>
                )}
              </div>
              <h4 className="font-semibold text-foreground text-sm">{type}</h4>
              {doc ? (
                <div className="mt-3 flex items-center gap-3">
                  <p className="text-xs text-muted-foreground">Uploaded: {doc.uploadedDate}</p>
                  <button className="text-primary hover:underline text-xs font-medium flex items-center gap-1">
                    <Eye size={12} /> View
                  </button>
                </div>
              ) : (
                <button className="mt-3 text-xs text-primary font-medium hover:underline flex items-center gap-1">
                  <Upload size={12} /> Upload now
                </button>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Upload, CheckCircle } from 'lucide-react';

const activityTypes = ['Hackathon', 'Internship', 'Research Paper', 'Technical Competition', 'Workshop', 'Cultural', 'Sports'];
const semesters = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th'];
const academicYears = ['2024-25', '2023-24', '2022-23', '2021-22'];

export default function AchievementUpload() {
  const { user, addAchievement } = useAuth();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    title: '', description: '', type: 'Hackathon',
    academicYear: '2024-25', semester: '6th', organizer: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    addAchievement({ ...form, studentId: user?.id });
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setForm({ title: '', description: '', type: 'Hackathon', academicYear: '2024-25', semester: '6th', organizer: '' });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-xl font-display font-bold text-foreground">Upload Achievement</h2>

      {submitted && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-success/10 text-success px-4 py-3 rounded-lg flex items-center gap-2 text-sm font-medium"
        >
          <CheckCircle size={18} /> Achievement submitted! Your profile strength increased.
        </motion.div>
      )}

      <motion.form
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={handleSubmit}
        className="bg-card rounded-2xl border border-border shadow-soft p-6 space-y-5"
      >
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Title *</label>
          <input
            required value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="e.g., Smart India Hackathon 2024"
            className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Description</label>
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Brief description of your achievement"
            rows={3}
            className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Activity Type *</label>
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value })}
              className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
            >
              {activityTypes.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Organizer</label>
            <input
              value={form.organizer}
              onChange={(e) => setForm({ ...form, organizer: e.target.value })}
              placeholder="e.g., AICTE"
              className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Academic Year *</label>
            <select
              value={form.academicYear}
              onChange={(e) => setForm({ ...form, academicYear: e.target.value })}
              className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
            >
              {academicYears.map(y => <option key={y}>{y}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Semester *</label>
            <select
              value={form.semester}
              onChange={(e) => setForm({ ...form, semester: e.target.value })}
              className="w-full px-4 py-3 bg-background border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
            >
              {semesters.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Upload Certificate</label>
          <div className="border-2 border-dashed border-border rounded-lg px-6 py-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
            <Upload className="mx-auto text-muted-foreground mb-2" size={24} />
            <p className="text-sm text-muted-foreground">Click to upload or drag & drop</p>
            <p className="text-xs text-muted-foreground mt-1">PDF, PNG, JPG (Max 5MB)</p>
          </div>
        </div>

        <button type="submit" className="w-full gradient-brand text-primary-foreground py-3.5 rounded-lg font-bold text-sm hover:opacity-90 transition-opacity">
          Submit Achievement
        </button>
      </motion.form>
    </div>
  );
}

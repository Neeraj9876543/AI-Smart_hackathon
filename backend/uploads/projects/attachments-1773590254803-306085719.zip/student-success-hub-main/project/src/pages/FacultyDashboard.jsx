import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Users, Calendar, Award, TrendingUp, Clock } from 'lucide-react';

export default function FacultyDashboard() {
  const stats = [
    {
      title: 'Total Courses',
      value: '4',
      change: '+1 this semester',
      icon: BookOpen,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Total Students',
      value: '186',
      change: '+24 new students',
      icon: Users,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Pending Assignments',
      value: '12',
      change: '3 due today',
      icon: Calendar,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      title: 'Average Grade',
      value: '78.5%',
      change: '+2.3% improvement',
      icon: TrendingUp,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'assignment',
      title: 'Data Structures Assignment',
      course: 'CSE301',
      students: 45,
      dueDate: '2024-03-20',
      status: 'active'
    },
    {
      id: 2,
      type: 'exam',
      title: 'Mid-term Examination',
      course: 'CSE302',
      students: 42,
      dueDate: '2024-03-25',
      status: 'upcoming'
    },
    {
      id: 3,
      type: 'assignment',
      title: 'Algorithm Project',
      course: 'CSE301',
      students: 38,
      dueDate: '2024-03-18',
      status: 'grading'
    }
  ];

  const topPerformers = [
    { name: 'Alice Johnson', regNo: '21A91A0101', avgGrade: '92%', course: 'CSE301' },
    { name: 'Bob Smith', regNo: '21A91A0102', avgGrade: '89%', course: 'CSE302' },
    { name: 'Carol Davis', regNo: '21A91A0103', avgGrade: '87%', course: 'CSE301' },
    { name: 'David Wilson', regNo: '21A91A0104', avgGrade: '85%', course: 'CSE303' }
  ];

  return (
    <div className="p-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-foreground">Faculty Dashboard</h1>
        <p className="text-muted-foreground mt-2">Welcome back! Here's an overview of your academic activities.</p>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card rounded-xl p-6 border border-border"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{stat.change}</p>
              </div>
              <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 bg-card rounded-xl p-6 border border-border"
        >
          <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Recent Activities
          </h2>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
                <div className="flex-1">
                  <h3 className="font-medium text-foreground">{activity.title}</h3>
                  <p className="text-sm text-muted-foreground">{activity.course} • {activity.students} students</p>
                  <p className="text-xs text-muted-foreground mt-1">Due: {activity.dueDate}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    activity.status === 'active' ? 'bg-green-100 text-green-800' :
                    activity.status === 'upcoming' ? 'bg-blue-100 text-blue-800' :
                    'bg-orange-100 text-orange-800'
                  }`}>
                    {activity.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Top Performers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Award className="w-5 h-5" />
            Top Performers
          </h2>
          <div className="space-y-3">
            {topPerformers.map((student, index) => (
              <div key={student.regNo} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-xs font-semibold text-primary">{index + 1}</span>
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">{student.name}</p>
                    <p className="text-xs text-muted-foreground">{student.regNo}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-foreground text-sm">{student.avgGrade}</p>
                  <p className="text-xs text-muted-foreground">{student.course}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-card rounded-xl p-6 border border-border"
      >
        <h2 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="p-4 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors">
            <BookOpen className="w-6 h-6 mb-2" />
            <p className="font-medium">Create Assignment</p>
          </button>
          <button className="p-4 bg-secondary rounded-lg hover:bg-secondary/80 transition-colors">
            <Users className="w-6 h-6 mb-2" />
            <p className="font-medium">View Students</p>
          </button>
          <button className="p-4 bg-secondary rounded-lg hover:bg-secondary/80 transition-colors">
            <Calendar className="w-6 h-6 mb-2" />
            <p className="font-medium">Schedule Exam</p>
          </button>
        </div>
      </motion.div>
    </div>
  );
}

import React from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Trophy, FileCheck, Calendar, Percent, ArrowUpRight } from 'lucide-react';
import { Doughnut, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

const StatCard = ({ icon: Icon, label, value, subtext, colorClass, index }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.1 }}
    className="bg-card p-6 rounded-2xl border border-border shadow-soft"
  >
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${colorClass}`}>
      <Icon size={20} />
    </div>
    <p className="text-muted-foreground text-sm font-medium">{label}</p>
    <h3 className="text-2xl font-bold text-foreground mt-1">{value}</h3>
    <p className="text-xs text-muted-foreground mt-2">{subtext}</p>
  </motion.div>
);

export default function StudentDashboard() {
  const { user, getStudentAchievements, getStudentDocs } = useAuth();
  const achievements = getStudentAchievements(user?.id);
  const documents = getStudentDocs(user?.id);
  const verified = documents.filter(d => d.status === 'Verified').length;

  const typeCount = achievements.reduce((acc, a) => {
    acc[a.type] = (acc[a.type] || 0) + 1;
    return acc;
  }, {});

  const doughnutData = {
    labels: Object.keys(typeCount),
    datasets: [{
      data: Object.values(typeCount),
      backgroundColor: ['#2563EB', '#06B6D4', '#F59E0B', '#10B981', '#8B5CF6', '#EF4444', '#EC4899'],
      borderWidth: 0,
    }]
  };

  const yearCount = achievements.reduce((acc, a) => {
    acc[a.academicYear] = (acc[a.academicYear] || 0) + 1;
    return acc;
  }, {});

  const barData = {
    labels: Object.keys(yearCount),
    datasets: [{
      label: 'Achievements',
      data: Object.values(yearCount),
      backgroundColor: '#2563EB',
      borderRadius: 8,
      barThickness: 32,
    }]
  };

  const recentAchievements = achievements.slice(0, 4);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard icon={Trophy} label="Total Achievements" value={achievements.length} subtext={`${achievements.filter(a => a.status === 'Verified').length} verified`} colorClass="bg-warning/10 text-warning" index={0} />
        <StatCard icon={FileCheck} label="Documents Verified" value={`${verified}/${documents.length}`} subtext={`${documents.length - verified} pending review`} colorClass="bg-success/10 text-success" index={1} />
        <StatCard icon={Calendar} label="Current Semester" value={user?.semester || '6th'} subtext={`Academic Year ${user?.academicYear}`} colorClass="bg-primary/10 text-primary" index={2} />
        <StatCard icon={Percent} label="Profile Completion" value={`${user?.profileCompletion}%`} subtext="Add ABC ID to reach 100%" colorClass="bg-accent/10 text-accent" index={3} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-card rounded-2xl border border-border shadow-soft overflow-hidden"
        >
          <div className="p-6 border-b border-border flex justify-between items-center">
            <h3 className="font-bold text-foreground">Recent Achievements</h3>
            <button className="text-primary text-sm font-semibold hover:underline flex items-center gap-1">
              View All <ArrowUpRight size={14} />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-secondary/50">
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Achievement</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Category</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {recentAchievements.map((item, i) => (
                  <tr key={i} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-4 font-medium text-sm text-foreground">{item.title}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{item.type}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{item.date}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        item.status === 'Verified' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Upload CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="gradient-dark rounded-3xl p-8 text-primary-foreground relative overflow-hidden shadow-xl"
        >
          <div className="relative z-10">
            <h3 className="text-xl font-bold mb-2">New Achievement?</h3>
            <p className="text-primary-foreground/70 text-sm mb-6">Upload your certificates and keep your digital portfolio updated for placements.</p>
            <button className="w-full bg-card text-foreground py-3 rounded-xl font-bold text-sm hover:bg-card/90 transition-colors">
              Upload Certificate
            </button>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary/20 rounded-full blur-3xl" />
        </motion.div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-card p-6 rounded-2xl border border-border shadow-soft"
        >
          <h3 className="font-bold text-foreground mb-6">Achievement Categories</h3>
          <div className="max-w-[280px] mx-auto">
            <Doughnut data={doughnutData} options={{ plugins: { legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true, pointStyleWidth: 8 } } }, cutout: '65%' }} />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-card p-6 rounded-2xl border border-border shadow-soft"
        >
          <h3 className="font-bold text-foreground mb-6">Achievements by Year</h3>
          <Bar data={barData} options={{ plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } }, x: { grid: { display: false } } } }} />
        </motion.div>
      </div>
    </div>
  );
}

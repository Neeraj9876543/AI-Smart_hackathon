import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Search, User, FileText, Trophy, CheckCircle, Clock } from 'lucide-react';

export default function AdminSearch() {
  const { students, getStudentDocs, getStudentAchievements } = useAuth();
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);

  const results = query.length > 0
    ? students.filter(s => s.regNo.toLowerCase().includes(query.toLowerCase()) || s.name.toLowerCase().includes(query.toLowerCase()))
    : [];

  const student = selected;
  const docs = student ? getStudentDocs(student.id) : [];
  const achs = student ? getStudentAchievements(student.id) : [];

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-display font-bold text-foreground">Search Students</h2>

      <div className="relative max-w-lg">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
        <input
          value={query}
          onChange={(e) => { setQuery(e.target.value); setSelected(null); }}
          placeholder="Search by Registration Number or Name..."
          className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>

      {query && !selected && results.length > 0 && (
        <div className="bg-card border border-border rounded-xl shadow-soft overflow-hidden max-w-lg">
          {results.map(s => (
            <button
              key={s.id}
              onClick={() => setSelected(s)}
              className="w-full px-4 py-3 flex items-center gap-3 hover:bg-secondary/50 transition-colors text-left border-b border-border/50 last:border-0"
            >
              <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center text-primary-foreground text-xs font-bold">
                {s.name.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{s.name}</p>
                <p className="text-xs text-muted-foreground">{s.regNo} • {s.branch}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {query && results.length === 0 && !selected && (
        <div className="bg-card rounded-2xl border border-border shadow-soft p-8 text-center max-w-lg">
          <Search className="mx-auto text-muted-foreground mb-3" size={32} />
          <p className="text-foreground font-medium">No students found</p>
          <p className="text-muted-foreground text-sm mt-1">Try a different registration number</p>
        </div>
      )}

      {selected && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {/* Profile Card */}
          <div className="bg-card rounded-2xl border border-border shadow-soft p-6 flex items-center gap-6">
            <div className="w-16 h-16 rounded-2xl gradient-brand flex items-center justify-center text-primary-foreground text-2xl font-bold overflow-hidden">
              {student.photo ? <img src={student.photo} alt={student.name} className="w-full h-full object-cover" /> : student.name.charAt(0)}
            </div>
            <div>
              <h3 className="text-lg font-bold text-foreground">{student.name}</h3>
              <p className="text-muted-foreground text-sm">{student.regNo} • {student.branch} • {student.year} Year • Section {student.section}</p>
              <p className="text-muted-foreground text-xs mt-1">{student.email} • {student.phone}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Documents */}
            <div className="bg-card rounded-2xl border border-border shadow-soft p-6">
              <h3 className="font-bold text-foreground mb-4 flex items-center gap-2"><FileText size={16} /> Documents</h3>
              <div className="space-y-3">
                {docs.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No documents uploaded</p>
                ) : docs.map(d => (
                  <div key={d.id} className="flex justify-between items-center py-2 border-b border-border/50 last:border-0">
                    <span className="text-sm text-foreground">{d.type}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      d.status === 'Verified' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                    }`}>{d.status}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Achievements */}
            <div className="bg-card rounded-2xl border border-border shadow-soft p-6">
              <h3 className="font-bold text-foreground mb-4 flex items-center gap-2"><Trophy size={16} /> Achievements</h3>
              <div className="space-y-3">
                {achs.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No achievements recorded</p>
                ) : achs.map(a => (
                  <div key={a.id} className="flex justify-between items-center py-2 border-b border-border/50 last:border-0">
                    <div>
                      <p className="text-sm font-medium text-foreground">{a.title}</p>
                      <p className="text-xs text-muted-foreground">{a.type} • {a.date}</p>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      a.status === 'Verified' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                    }`}>{a.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

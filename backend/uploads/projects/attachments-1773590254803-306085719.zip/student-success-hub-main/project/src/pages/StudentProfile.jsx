import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { User, Phone, Mail, MapPin, GraduationCap, Calendar, Edit3, Save, X } from 'lucide-react';

export default function StudentProfile() {
  const { user } = useAuth();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ ...user });

  const handleSave = () => {
    setEditing(false);
    // In real app, save to backend
  };

  const Section = ({ title, children }) => (
    <div className="bg-card rounded-2xl border border-border shadow-soft p-6">
      <h3 className="font-bold text-foreground mb-4 text-sm uppercase tracking-wider">{title}</h3>
      {children}
    </div>
  );

  const Field = ({ label, value, field }) => (
    <div>
      <p className="text-xs text-muted-foreground font-medium mb-1">{label}</p>
      {editing && field ? (
        <input
          value={form[field] || ''}
          onChange={(e) => setForm({ ...form, [field]: e.target.value })}
          className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      ) : (
        <p className="text-sm font-medium text-foreground">{value || '—'}</p>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-display font-bold text-foreground">Student Profile</h2>
        {editing ? (
          <div className="flex gap-2">
            <button onClick={() => setEditing(false)} className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary">
              <X size={16} /> Cancel
            </button>
            <button onClick={handleSave} className="flex items-center gap-2 px-4 py-2 gradient-brand text-primary-foreground rounded-lg text-sm font-medium">
              <Save size={16} /> Save
            </button>
          </div>
        ) : (
          <button onClick={() => setEditing(true)} className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary">
            <Edit3 size={16} /> Edit Profile
          </button>
        )}
      </div>

      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-2xl border border-border shadow-soft p-6 flex flex-col sm:flex-row items-center gap-6"
      >
        <div className="w-24 h-24 rounded-2xl gradient-brand flex items-center justify-center text-primary-foreground text-3xl font-bold overflow-hidden">
          {user?.photo ? (
            <img src={user.photo} alt={user.name} className="w-full h-full object-cover" />
          ) : (
            user?.name?.charAt(0)
          )}
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">{user?.name}</h2>
          <p className="text-muted-foreground text-sm">{user?.regNo} • {user?.branch} • {user?.year} Year</p>
          <div className="flex items-center gap-1 mt-2">
            <div className="h-2 flex-1 max-w-[200px] bg-secondary rounded-full overflow-hidden">
              <div className="h-full gradient-brand rounded-full" style={{ width: `${user?.profileCompletion}%` }} />
            </div>
            <span className="text-xs font-medium text-muted-foreground">{user?.profileCompletion}% complete</span>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Section title="Personal Details">
            <div className="grid grid-cols-2 gap-4">
              <Field label="Full Name" value={user?.name} field="name" />
              <Field label="Date of Birth" value={user?.dob} field="dob" />
              <Field label="Gender" value={user?.gender} field="gender" />
              <Field label="Email" value={user?.email} field="email" />
            </div>
          </Section>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Section title="Academic Details">
            <div className="grid grid-cols-2 gap-4">
              <Field label="Registration No." value={user?.regNo} />
              <Field label="Branch" value={user?.branch} />
              <Field label="Section" value={user?.section} />
              <Field label="Semester" value={user?.semester} />
              <Field label="Academic Year" value={user?.academicYear} />
              <Field label="Year" value={user?.year} />
            </div>
          </Section>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Section title="Admission Details">
            <div className="grid grid-cols-2 gap-4">
              <Field label="Admission Category" value={user?.admissionCategory} />
            </div>
          </Section>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Section title="Contact Details">
            <div className="grid grid-cols-1 gap-4">
              <Field label="Phone" value={user?.phone} field="phone" />
              <Field label="Address" value={user?.address} field="address" />
            </div>
          </Section>
        </motion.div>
      </div>
    </div>
  );
}
